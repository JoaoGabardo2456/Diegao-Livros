package br.com.unicuritiba.Livraria.services;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.unicuritiba.Livraria.models.Livros;

public interface LivrosRepository extends JpaRepository<Livros, Integer>{

}
