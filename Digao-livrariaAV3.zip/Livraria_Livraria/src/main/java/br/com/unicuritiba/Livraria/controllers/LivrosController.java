package br.com.unicuritiba.Livraria.controllers;

import java.nio.file.Files;
import java.io.InputStream;
import java.nio.file.*;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.com.unicuritiba.Livraria.models.LivroDto;
import br.com.unicuritiba.Livraria.models.Livros;
import br.com.unicuritiba.Livraria.services.LivrosRepository;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/livros")
public class LivrosController {
	
	@Autowired
	private LivrosRepository repo;
	
	@GetMapping({"", "/"})
	public String showLivrosList(Model model) {
		List<Livros> livros = repo.findAll(Sort.by(Sort.Direction.DESC, "id"));
		model.addAttribute("livros", livros);
		return "livros/index";
	}
	
	@GetMapping({"/create"})
	public String showCreatePage(Model model) {
		LivroDto livroDto = new LivroDto();
		model.addAttribute("livroDto", livroDto);
		return "livros/CreateLivro";
	}
	
	@PostMapping("/create")
	public String createLivro(
			@Valid @ModelAttribute LivroDto livroDto,
			BindingResult result) {
		
		if (livroDto.getImageFile().isEmpty()) {
			result.addError(new FieldError("livroDto", "imageFile", "O arquivo de imagem é obrigatório!"));
		}
		
		if (result.hasErrors()) {
			return "livros/CreateLivro";
		}
		
		MultipartFile image = livroDto.getImageFile();
		Date createdAt = new Date();
		String storageFileName = createdAt.getTime() + "_" + image.getOriginalFilename(); 
		
		try {
			String uploadDir = "public/images/";
			Path uploadPath = Paths.get(uploadDir);
			
			if (!Files.exists(uploadPath)) {
				Files.createDirectories(uploadPath);
			}
			
		try (InputStream inputStream = image.getInputStream()) {
			Files.copy(inputStream, Paths.get(uploadDir + storageFileName),
					StandardCopyOption.REPLACE_EXISTING);
		}	
		} catch (Exception ex) {
			System.out.println("Exception: " + ex.getMessage());
		}
		
		Livros livro = new Livros();
		livro.setName(livroDto.getName());
		livro.setAutor(livroDto.getAutor());
		livro.setEditora(livroDto.getEditora());
		livro.setCreatedAt(createdAt);
		livro.setImageFileName(storageFileName);
		
		repo.save(livro);
		
		return "redirect:/livros";
	}
	
	@GetMapping("/edit")
	public String showEditPage (
			Model model,
			@RequestParam int id) {
		
		try {
			Livros livro = repo.findById(id).get();
			model.addAttribute("livro", livro);
			
			LivroDto livroDto = new LivroDto();
			livroDto.setName(livro.getName());
			livroDto.setAutor(livro.getAutor());
			livroDto.setEditora(livro.getEditora());
			
			model.addAttribute("livroDto", livroDto);
			
		}
		catch(Exception ex) {
		System.out.println("Exception :" + ex.getMessage());
		return "redirect:/livros";
		}
		return "livros/EditLivro";
	}
	
	@PostMapping("/edit")
	public String updateLivro (
			Model model,
			@RequestParam int id,
			@Valid @ModelAttribute LivroDto livroDto,
			BindingResult result) {
		
		try {
			Livros livro = repo.findById(id).get();
			model.addAttribute("livro", livro);
			
			if (result.hasErrors()) {
				return "livros/EditLivro";
			}
			
			if (!livroDto.getImageFile().isEmpty()) {
				String uploadDir = "public/images";
				Path oldImagePath = Paths.get(uploadDir + livro.getImageFileName());
				
				try {
					Files.delete(oldImagePath);
				}
				catch(Exception ex) {
					System.out.println("Exception: " + ex.getMessage());
				}
				
				MultipartFile image = livroDto.getImageFile();
				Date createdAt = new Date();
				String storageFileName = createdAt.getTime() + "_" + image.getOriginalFilename();
				
				try (InputStream inputStream = image.getInputStream()){
					Files.copy(inputStream, Paths.get(uploadDir + storageFileName),
							StandardCopyOption.REPLACE_EXISTING);
				}
				livro.setImageFileName(storageFileName);
			}
			
			livro.setName(livroDto.getName());
			livro.setAutor(livroDto.getAutor());
			livro.setEditora(livroDto.getEditora());
			
			repo.save(livro);
			
		}
		catch(Exception ex) {
			System.out.println("Exception:"  + ex.getMessage());
		}
		
		return "redirect:/livros";
	}
	
	@GetMapping("/delete")
	public String deleteLivro (
			@RequestParam int id) {
		try {
			Livros livro = repo.findById(id).get();
			
			Path imagePath = Paths.get("public/images/" + livro.getImageFileName());
			
			try {
				Files.delete(imagePath);
			}
			catch (Exception ex) {
				System.out.println("Exception: " + ex.getMessage());
			}
			
			repo.delete(livro);
			
		}
		catch (Exception ex) {
			System.out.println("Exception: " + ex.getMessage());
		}
		
		return "redirect:/livros";
	}
}
