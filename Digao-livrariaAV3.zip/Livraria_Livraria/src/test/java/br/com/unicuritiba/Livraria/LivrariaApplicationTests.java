package br.com.unicuritiba.Livraria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivrariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
